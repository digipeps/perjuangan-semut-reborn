PERJUANGAN SEMUT REBORN — ANDROID WEBVIEW PROJECT

Yang sudah disiapkan:
- Activity Android dikunci ke landscape melalui AndroidManifest.
- Fullscreen immersive menyembunyikan status bar dan navigation bar.
- Game HTML dimuat dari assets lokal sehingga mode inti dapat dibuka offline.
- CSS rotasi portrait dinonaktifkan; ukuran game mengikuti viewport landscape asli.
- JavaScript dan DOM storage diaktifkan untuk game.

Cara membuat APK:
1. Buka folder project ini dengan Android Studio.
2. Pastikan Android SDK Platform 35 dan Android Gradle Plugin yang diminta terpasang.
3. Tunggu Gradle Sync selesai.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug akan muncul di app/build/outputs/apk/debug/.

Catatan penting:
- Lingkungan pembuatan ini tidak memiliki Android SDK, Gradle, atau adb, jadi APK belum dapat dikompilasi maupun diuji pada perangkat.
- Fitur online/room tetap bergantung pada backend/server room yang digunakan oleh HTML. Pembungkus APK ini tidak menyediakan server baru.
- Ini adalah prototipe pembungkus native Android, belum APK final yang sudah teruji.


CARA MEMBUAT APK TANPA ANDROID STUDIO:
1. Buat repository baru di GitHub.
2. Unggah seluruh isi folder proyek ini ke repository, termasuk folder tersembunyi .github/workflows.
3. Buka tab Actions.
4. Jalankan workflow "Build Perjuangan Semut APK" dengan tombol Run workflow.
5. Setelah proses selesai, buka hasil run dan unduh artifact "Perjuangan-Semut-Reborn-APK".
6. Ekstrak ZIP artifact lalu instal app-debug.apk di HP.

GitHub Actions akan mengompilasi APK di cloud. Android Studio tidak perlu dipasang, tetapi kamu memerlukan akun GitHub dan koneksi internet.
